This directory contains a set of images (*.bmp) and audio file to be used
with the following demonstrations:
   - \Projects\STM32F030R8-Nucleo\Demonstrations
   - \Projects\STM32F070RB-Nucleo\Demonstrations
   - \Projects\STM32F072RB-Nucleo\Demonstrations
   - \Projects\STM32F091RC-Nucleo\Demonstrations
